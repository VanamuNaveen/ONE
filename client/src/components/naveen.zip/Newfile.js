import React from "react"
function Newfile(){
    return(
        <div>hello mova
        <h1>strong</h1>
        
       
        </div>
        
    )
}
export default Newfile