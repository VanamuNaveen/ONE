import React from "react";
import { Link } from "react-router-dom";
function One2(){
    return(
        <div>
        <p>home2</p> 
            <Link to='/ONE'>HOMEONE</Link>
        </div>
    )
}
export default One2