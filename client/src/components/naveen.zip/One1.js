import React from "react";
import { Link } from "react-router-dom";
function One1(){
    return(
        <div>
            <Link to='/ONE'>homeONE</Link>
        </div>
    )
}
export default One1