// var React = require("react");
// var ReactDOM = require("react-dom");

// ReactDOM.render(<h1>hello</h1>,document.getElementById("root"));
import React from "react"
function Gain(){
    const name = "abcde";
    const num = "21";
    return(
        <div>
        {
            alert("hello")
           
        }
       {
        alert("hello"+ name)
       }
       <p>you number is {num}</p>
      
        <h1>{name}</h1>
        </div>
    
    )
}
export default Gain
