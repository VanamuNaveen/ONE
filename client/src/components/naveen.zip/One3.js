import React from "react";
import { Link } from "react-router-dom";
function One3(){
    return(
        <div>
        <p>Home3</p>
            <Link to='/ONE'>HOMEONE</Link>
        </div>
    )
}
export default One3